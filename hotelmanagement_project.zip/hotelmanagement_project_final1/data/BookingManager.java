
package data;

import model.Booking;
import java.io.*;
import java.util.*;

public class BookingManager {
    private static final String BOOKINGS_FILE = "bookings.dat";
    private static final String BILLS_FILE = "bills.txt";
    private static Map<Integer, Double> roomRates = new HashMap<>();
    private static List<Booking> bookings = new ArrayList<>();

    static {
        roomRates.put(101, 2000.0);
        roomRates.put(102, 1800.0);
        roomRates.put(103, 1500.0);
        roomRates.put(104, 1700.0);
        roomRates.put(201, 2200.0);
        roomRates.put(202, 2500.0);
        roomRates.put(203, 2300.0);
        roomRates.put(204, 2400.0);
        roomRates.put(301, 3000.0);
        roomRates.put(302, 2800.0);
        loadBookings();
    }

    public static List<Booking> getBookings() {
        return bookings;
    }

    public static boolean isRoomAvailable(int roomNumber) {
        for (Booking b : bookings) {
            if (b.getRoomNumber() == roomNumber) {
                return false;
            }
        }
        return true;
    }

    public static double getRoomRate(int roomNumber) {
        return roomRates.getOrDefault(roomNumber, 0.0);
    }

    public static void addBooking(Booking booking) {
        bookings.add(booking);
        saveBookings();
        saveBill(booking);
    }

    private static void loadBookings() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(BOOKINGS_FILE))) {
            bookings = (List<Booking>) ois.readObject();
        } catch (Exception e) {
            bookings = new ArrayList<>();
        }
    }

    private static void saveBookings() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(BOOKINGS_FILE))) {
            oos.writeObject(bookings);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void saveBill(Booking booking) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(BILLS_FILE, true))) {
            bw.write("Customer: " + booking.getCustomerName() + ", Phone: " + booking.getCustomerPhone() +
                    ", Room: " + booking.getRoomNumber() + ", Days: " + booking.getNumberOfDays() +
                    ", Total: " + booking.getTotalCost());
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Map<Integer, Double> getRoomRates() {
        return roomRates;
    }
}
