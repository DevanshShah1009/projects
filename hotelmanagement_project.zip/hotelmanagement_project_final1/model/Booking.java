
package model;

import java.io.Serializable;

public class Booking implements Serializable {
    private String customerName;
    private String customerPhone;
    private int roomNumber;
    private int numberOfDays;
    private double totalCost;

    public Booking(String customerName, String customerPhone, int roomNumber, int numberOfDays, double totalCost) {
        this.customerName = customerName;
        this.customerPhone = customerPhone;
        this.roomNumber = roomNumber;
        this.numberOfDays = numberOfDays;
        this.totalCost = totalCost;
    }

    public String getCustomerName() { return customerName; }
    public String getCustomerPhone() { return customerPhone; }
    public int getRoomNumber() { return roomNumber; }
    public int getNumberOfDays() { return numberOfDays; }
    public double getTotalCost() { return totalCost; }
}
