package ui;

import data.BookingManager;
import java.awt.*;
import javax.swing.*;
import model.Booking;

public class BookingUI extends JFrame {

    private Image backgroundImage;

    public BookingUI() {
        setTitle("Book a Room");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Load the background image
        backgroundImage = new ImageIcon("icons/booking.jpg").getImage();

        // Create custom panel
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    int panelWidth = getWidth();
                    int panelHeight = getHeight();
                    int imgWidth = backgroundImage.getWidth(this);
                    int imgHeight = backgroundImage.getHeight(this);

                    int x = (panelWidth - imgWidth) / 2;
                    int y = (panelHeight - imgHeight) / 2;

                    g.drawImage(backgroundImage, x, y, this);
                }
            }
        };
        backgroundPanel.setLayout(null); // For absolute positioning

        // Labels and fields
        JLabel nameLabel = new JLabel("Customer Name:");
        nameLabel.setBounds(100, 100, 150, 30);
        JTextField nameField = new JTextField();
        nameField.setBounds(300, 100, 200, 30);

        JLabel phoneLabel = new JLabel("Customer Phone:");
        phoneLabel.setBounds(100, 150, 150, 30);
        JTextField phoneField = new JTextField();
        phoneField.setBounds(300, 150, 200, 30);

        JLabel roomLabel = new JLabel("Room Number:");
        roomLabel.setBounds(100, 200, 150, 30);
        JTextField roomField = new JTextField();
        roomField.setBounds(300, 200, 200, 30);

        JLabel daysLabel = new JLabel("Number of Days:");
        daysLabel.setBounds(100, 250, 150, 30);
        JTextField daysField = new JTextField();
        daysField.setBounds(300, 250, 200, 30);

        // Book button
        JButton bookButton = new JButton("Book Now");
        bookButton.setBounds(300, 300, 150, 40);
        bookButton.addActionListener(e -> {
            try {
                String name = nameField.getText();
                String phone = phoneField.getText();
                int roomNo = Integer.parseInt(roomField.getText());
                int days = Integer.parseInt(daysField.getText());

                if (!BookingManager.isRoomAvailable(roomNo)) {
                    JOptionPane.showMessageDialog(this, "Room already booked!");
                    return;
                }

                double rate = BookingManager.getRoomRate(roomNo);
                double total = rate * days;
                Booking booking = new Booking(name, phone, roomNo, days, total);
                BookingManager.addBooking(booking);
                JOptionPane.showMessageDialog(this, "Booking Successful! Bill: ₹" + total);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers for Room and Days.");
            }
        });

        // Back button
        JButton backButton = new JButton("← Dashboard");
        backButton.setBounds(50, 20, 150, 30);
        backButton.addActionListener(e -> {
            dispose();
            new DashboardUI();
        });

        // Add all components to the background panel
        backgroundPanel.add(nameLabel);
        backgroundPanel.add(nameField);
        backgroundPanel.add(phoneLabel);
        backgroundPanel.add(phoneField);
        backgroundPanel.add(roomLabel);
        backgroundPanel.add(roomField);
        backgroundPanel.add(daysLabel);
        backgroundPanel.add(daysField);
        backgroundPanel.add(bookButton);
        backgroundPanel.add(backButton);

        // Set the background panel as the content pane
        setContentPane(backgroundPanel);

        setVisible(true);
    }
}
