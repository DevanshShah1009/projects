package ui;

import data.BookingManager;
import java.awt.*;
import java.util.Map;
import javax.swing.*;

public class RoomAvailabilityUI extends JFrame {

    private Image backgroundImage;

    public RoomAvailabilityUI() {
        setTitle("Room Availability");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Load the background image
        backgroundImage = new ImageIcon("icons/background.jpg").getImage();

        // Create custom panel
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    int panelWidth = getWidth();
                    int panelHeight = getHeight();
                    int imgWidth = backgroundImage.getWidth(this);
                    int imgHeight = backgroundImage.getHeight(this);

                    int x = (panelWidth - imgWidth) / 2;
                    int y = (panelHeight - imgHeight) / 2;

                    g.drawImage(backgroundImage, x, y, this);
                }
            }
        };
        backgroundPanel.setLayout(null); // Allow manual positioning

        // Text area to show room availability
        JTextArea textArea = new JTextArea();
        textArea.setBounds(100, 100, 600, 400);
        textArea.setEditable(false);

        StringBuilder info = new StringBuilder();
        for (Map.Entry<Integer, Double> entry : BookingManager.getRoomRates().entrySet()) {
            boolean available = BookingManager.isRoomAvailable(entry.getKey());
            info.append("Room ").append(entry.getKey())
                .append(" (₹").append(entry.getValue()).append("/day) - ")
                .append(available ? "Available" : "Booked").append("\n");
        }
        textArea.setText(info.toString());

        // Back button
        JButton backButton = new JButton("← Dashboard");
        backButton.setBounds(50, 20, 150, 30);
        backButton.addActionListener(e -> {
            dispose();
            new DashboardUI();
        });

        // Add components to background panel
        backgroundPanel.add(textArea);
        backgroundPanel.add(backButton);

        // Set custom panel as content pane
        setContentPane(backgroundPanel);

        setVisible(true);
    }
}
