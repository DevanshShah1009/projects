package ui;

import java.awt.*;
import javax.swing.*;

public class DashboardUI extends JFrame {

    private Image backgroundImage;

    public DashboardUI() {
        setTitle("Hotel Management Dashboard");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Load the background image
        backgroundImage = new ImageIcon("icons/dashboard.jpg").getImage();

        // Create custom panel
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    int panelWidth = getWidth();
                    int panelHeight = getHeight();
                    int imgWidth = backgroundImage.getWidth(this);
                    int imgHeight = backgroundImage.getHeight(this);

                    int x = (panelWidth - imgWidth) / 2;
                    int y = (panelHeight - imgHeight) / 2;

                    g.drawImage(backgroundImage, x, y, this);
                }
            }
        };
        backgroundPanel.setLayout(null); // Allow absolute positioning

        // Add buttons
        JButton bookingButton = new JButton("Book Room");
        bookingButton.setBounds(100, 100, 200, 50);
        bookingButton.addActionListener(e -> {
            dispose();
            new BookingUI();
        });

        JButton availabilityButton = new JButton("Room Availability");
        availabilityButton.setBounds(100, 200, 200, 50);
        availabilityButton.addActionListener(e -> {
            dispose();
            new RoomAvailabilityUI();
        });

        JButton billingButton = new JButton("Billing History");
        billingButton.setBounds(100, 300, 200, 50);
        billingButton.addActionListener(e -> {
            dispose();
            new BillingUI();
        });

        JButton exitButton = new JButton("Exit");
        exitButton.setBounds(100, 400, 200, 50);
        exitButton.addActionListener(e -> System.exit(0));

        // Add buttons to background panel
        backgroundPanel.add(bookingButton);
        backgroundPanel.add(availabilityButton);
        backgroundPanel.add(billingButton);
        backgroundPanel.add(exitButton);

        // Set the background panel as the content pane
        setContentPane(backgroundPanel);

        setVisible(true);
    }

    public static void main(String[] args) {
        new DashboardUI();
    }
}
