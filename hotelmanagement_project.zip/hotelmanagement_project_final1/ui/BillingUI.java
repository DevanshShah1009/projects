package ui;

import java.awt.*;
import java.io.*;
import javax.swing.*;

public class BillingUI extends JFrame {

    private Image backgroundImage;

    public BillingUI() {
        setTitle("Billing History");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Load the background image
        backgroundImage = new ImageIcon("icons/bill.jpg").getImage();

        // Create a custom background panel
        JPanel backgroundPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                if (backgroundImage != null) {
                    int panelWidth = getWidth();
                    int panelHeight = getHeight();
                    int imgWidth = backgroundImage.getWidth(this);
                    int imgHeight = backgroundImage.getHeight(this);

                    int x = (panelWidth - imgWidth) / 2;
                    int y = (panelHeight - imgHeight) / 2;

                    g.drawImage(backgroundImage, x, y, this);
                }
            }
        };
        backgroundPanel.setLayout(null); // Absolute positioning

        // Billing area
        JTextArea billArea = new JTextArea();
        billArea.setBounds(100, 100, 800, 400);
        billArea.setEditable(false);

        // Read bills.txt
        try (BufferedReader br = new BufferedReader(new FileReader("bills.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                billArea.append(line + "\n");
            }
        } catch (IOException e) {
            billArea.setText("No billing records found.");
        }

        // Back button
        JButton backButton = new JButton("← Dashboard");
        backButton.setBounds(50, 20, 150, 30);
        backButton.addActionListener(e -> {
            dispose();
            new DashboardUI();
        });

        // Add components to the background panel
        backgroundPanel.add(billArea);
        backgroundPanel.add(backButton);

        // Set the background panel as the content pane
        setContentPane(backgroundPanel);

        setVisible(true);
    }
}
