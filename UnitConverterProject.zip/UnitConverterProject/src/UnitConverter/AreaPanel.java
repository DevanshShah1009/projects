package UnitConverter;

import javax.swing.*;

public class AreaPanel extends JPanel {
    private JComboBox<String> fromBox, toBox;
    private JTextField inputField, resultField;
    private JButton convertButton;

    // Base unit: square meter
    String[] units = {
        "Square meter",       // base unit
        "Square kilometer", 
        "Square mile", 
        "Acre", 
        "Hectare", 
        "Square centimeter", 
        "Square millimeter", 
        "Square decimeter",
        "Square inch", 
        "Square foot", 
        "Square yard", 
        "Are"
    };

    double[] values = {
        1.0,                    // Square meter
        1_000_000.0,            // Square kilometer
        2_589_988.110336,       // Square mile
        4046.8564224,           // Acre
        10_000.0,               // Hectare
        0.0001,                 // Square centimeter
        0.000001,               // Square millimeter
        0.01,                   // Square decimeter
        0.00064516,             // Square inch
        0.09290304,             // Square foot
        0.83612736,             // Square yard
        100.0                  // Are
    };

    public AreaPanel() {
        setLayout(null);
        setBounds(0, 0, 500, 400);

        JLabel fromLabel = new JLabel("From:");
        fromLabel.setBounds(50, 30, 100, 30);
        add(fromLabel);

        fromBox = new JComboBox<>(units);
        fromBox.setBounds(150, 30, 250, 30);
        add(fromBox);

        JLabel toLabel = new JLabel("To:");
        toLabel.setBounds(50, 80, 100, 30);
        add(toLabel);

        toBox = new JComboBox<>(units);
        toBox.setBounds(150, 80, 250, 30);
        add(toBox);

        JLabel inputLabel = new JLabel("Value:");
        inputLabel.setBounds(50, 130, 100, 30);
        add(inputLabel);

        inputField = new JTextField();
        inputField.setBounds(150, 130, 250, 30);
        add(inputField);

        convertButton = new JButton("Convert");
        convertButton.setBounds(200, 180, 100, 30);
        add(convertButton);

        JLabel resultLabel = new JLabel("Result:");
        resultLabel.setBounds(50, 230, 100, 30);
        add(resultLabel);

        resultField = new JTextField();
        resultField.setBounds(150, 230, 250, 30);
        resultField.setEditable(false);
        add(resultField);

        convertButton.addActionListener(e -> convert());
    }

    private void convert() {
        try {
            double input = Double.parseDouble(inputField.getText());
            double fromFactor = values[fromBox.getSelectedIndex()];
            double toFactor = values[toBox.getSelectedIndex()];
            double result = input * fromFactor / toFactor;
            resultField.setText(String.format("%.6f", result));
        } catch (NumberFormatException e) {
            resultField.setText("Invalid input");
        }
    }
}
