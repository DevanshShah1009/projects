package UnitConverter;

import javax.swing.*;

public class WeightPanel extends JPanel {
    private JComboBox<String> fromBox, toBox;
    private JTextField inputField, resultField;
    private JButton convertButton;

    // Base unit: Kilogram
    String[] units = {
        "Kilogram",   // base
        "Gram",
        "Milligram",
        "Tonne",
        "Quintal",
        "Pound",
        "Ounce"
    };

    // Conversion values relative to Kilogram
    double[] values = {
        1.0,            // Kilogram
        0.001,          // Gram
        0.000001,       // Milligram
        1000.0,         // Tonne
        100.0,          // Quintal
        0.45359237,     // Pound
        0.0283495231    // Ounce
    };

    public WeightPanel() {
        setLayout(null);
        setBounds(0, 0, 500, 400);

        JLabel fromLabel = new JLabel("From:");
        fromLabel.setBounds(50, 30, 100, 30);
        add(fromLabel);

        fromBox = new JComboBox<>(units);
        fromBox.setBounds(150, 30, 250, 30);
        add(fromBox);

        JLabel toLabel = new JLabel("To:");
        toLabel.setBounds(50, 80, 100, 30);
        add(toLabel);

        toBox = new JComboBox<>(units);
        toBox.setBounds(150, 80, 250, 30);
        add(toBox);

        JLabel inputLabel = new JLabel("Value:");
        inputLabel.setBounds(50, 130, 100, 30);
        add(inputLabel);

        inputField = new JTextField();
        inputField.setBounds(150, 130, 250, 30);
        add(inputField);

        convertButton = new JButton("Convert");
        convertButton.setBounds(200, 180, 100, 30);
        add(convertButton);

        JLabel resultLabel = new JLabel("Result:");
        resultLabel.setBounds(50, 230, 100, 30);
        add(resultLabel);

        resultField = new JTextField();
        resultField.setBounds(150, 230, 250, 30);
        resultField.setEditable(false);
        add(resultField);

        convertButton.addActionListener(e -> convert());
    }

    private void convert() {
        try {
            double input = Double.parseDouble(inputField.getText());
            double fromFactor = values[fromBox.getSelectedIndex()];
            double toFactor = values[toBox.getSelectedIndex()];
            double result = input * fromFactor / toFactor;
            resultField.setText(String.format("%.6f", result));
        } catch (NumberFormatException e) {
            resultField.setText("Invalid input");
        }
    }
}

