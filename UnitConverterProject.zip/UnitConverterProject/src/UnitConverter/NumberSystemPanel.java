package UnitConverter;

import javax.swing.*;

public class NumberSystemPanel extends JPanel {
    private JComboBox<String> fromBox, toBox;
    private JTextField inputField, resultField;
    private JButton convertButton;

    String[] systems = { "Binary", "Octal", "Decimal", "Hexadecimal" };

    public NumberSystemPanel() {
        setLayout(null);
        setBounds(0, 0, 500, 400);

        JLabel fromLabel = new JLabel("From:");
        fromLabel.setBounds(50, 30, 100, 30);
        add(fromLabel);

        fromBox = new JComboBox<>(systems);
        fromBox.setBounds(150, 30, 250, 30);
        add(fromBox);

        JLabel toLabel = new JLabel("To:");
        toLabel.setBounds(50, 80, 100, 30);
        add(toLabel);

        toBox = new JComboBox<>(systems);
        toBox.setBounds(150, 80, 250, 30);
        add(toBox);

        JLabel inputLabel = new JLabel("Number:");
        inputLabel.setBounds(50, 130, 100, 30);
        add(inputLabel);

        inputField = new JTextField();
        inputField.setBounds(150, 130, 250, 30);
        add(inputField);

        convertButton = new JButton("Convert");
        convertButton.setBounds(200, 180, 100, 30);
        add(convertButton);

        JLabel resultLabel = new JLabel("Result:");
        resultLabel.setBounds(50, 230, 100, 30);
        add(resultLabel);

        resultField = new JTextField();
        resultField.setBounds(150, 230, 250, 30);
        resultField.setEditable(false);
        add(resultField);

        convertButton.addActionListener(e -> convert());
    }

    private void convert() {
        try {
            String input = inputField.getText().trim();
            int fromBase = getBase(fromBox.getSelectedItem().toString());
            int toBase = getBase(toBox.getSelectedItem().toString());

            int decimalValue = Integer.parseInt(input, fromBase);
            String result = Integer.toString(decimalValue, toBase).toUpperCase();

            resultField.setText(result);
        } catch (NumberFormatException e) {
            resultField.setText("Invalid number");
        }
    }

    private int getBase(String system) {
        return switch (system) {
            case "Binary" -> 2;
            case "Octal" -> 8;
            case "Decimal" -> 10;
            case "Hexadecimal" -> 16;
            default -> 10;
        };
    }
}
