package UnitConverter;

import javax.swing.*;

public class LengthPanel extends JPanel {
    private JComboBox<String> fromBox, toBox;
    private JTextField inputField, resultField;
    private JButton convertButton;

    // Units for length conversion
    String[] units = {
        "Meter",
        "Kilometer",
        "Centimeter",
        "Millimeter",
        "Micrometer",
        "Nanometer",
        "Picometer",
        "Decimeter",
        "Mile",
        "Yard",
        "Foot",
        "Inch",
        "Light-year",
        "Parsec",
        "Astronomical Unit",
        "Lunar Distance"
    };

    // Conversion factors relative to 1 meter
    double[] values = {
        1.0,                      // Meter
        1000.0,                   // Kilometer
        0.01,                     // Centimeter
        0.001,                    // Millimeter
        1e-6,                     // Micrometer
        1e-9,                     // Nanometer
        1e-12,                    // Picometer
        0.1,                      // Decimeter
        1609.344,                 // Mile
        0.9144,                   // Yard
        0.3048,                   // Foot
        0.0254,                   // Inch
        9.461e15,                 // Light-year (approx)
        3.086e16,                 // Parsec (approx)
        1.496e11,                 // Astronomical Unit (AU)
        3.844e8                   // Lunar Distance (approx Earth-Moon avg)
    };

    public LengthPanel() {
        setLayout(null);
        setBounds(0, 0, 500, 450); // Adjusted height for potential future UI

        JLabel fromLabel = new JLabel("From:");
        fromLabel.setBounds(50, 30, 100, 30);
        add(fromLabel);

        fromBox = new JComboBox<>(units);
        fromBox.setBounds(150, 30, 250, 30);
        add(fromBox);

        JLabel toLabel = new JLabel("To:");
        toLabel.setBounds(50, 80, 100, 30);
        add(toLabel);

        toBox = new JComboBox<>(units);
        toBox.setBounds(150, 80, 250, 30);
        add(toBox);

        JLabel inputLabel = new JLabel("Value:");
        inputLabel.setBounds(50, 130, 100, 30);
        add(inputLabel);

        inputField = new JTextField();
        inputField.setBounds(150, 130, 250, 30);
        add(inputField);

        convertButton = new JButton("Convert");
        convertButton.setBounds(200, 180, 100, 30);
        add(convertButton);

        JLabel resultLabel = new JLabel("Result:");
        resultLabel.setBounds(50, 230, 100, 30);
        add(resultLabel);

        resultField = new JTextField();
        resultField.setBounds(150, 230, 250, 30);
        resultField.setEditable(false);
        add(resultField);

        convertButton.addActionListener(e -> convert());
    }

    private void convert() {
        try {
            double input = Double.parseDouble(inputField.getText());

            // Convert input to meters
            double fromInMeters = input * values[fromBox.getSelectedIndex()];
            // Convert meters to target unit
            double result = fromInMeters / values[toBox.getSelectedIndex()];

            resultField.setText(String.format("%.6f", result));
        } catch (NumberFormatException e) {
            resultField.setText("Invalid input");
        }
    }
}
