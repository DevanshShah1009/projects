package UnitConverter;
import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private CardLayout cardLayout;
    private JPanel mainCardPanel;
    private JPanel converterContainer;

    public MainFrame() {
        setTitle("UNIT CONVERTER");
        setSize(520,520);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        cardLayout = new CardLayout();
        mainCardPanel = new JPanel(cardLayout);

        // === Grid updated for 10 buttons (5 rows x 2 cols) ===
        JPanel menuPanel = new JPanel(new GridLayout(3, 3, 20, 20));    
        menuPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

         // === All converter buttons ===
         JButton areaBtn = new JButton("AREA");
         JButton angleBtn = new JButton("ANGLE");
         JButton lengthBtn = new JButton("LENGTH");
         JButton weightBtn = new JButton("WEIGHT");
         JButton currencyBtn = new JButton("CURRENCY");
         JButton tempBtn = new JButton("TEMPERATURE");
         JButton speedBtn = new JButton("SPEED");
         JButton pressureBtn = new JButton("PRESSURE");
         JButton numberBtn = new JButton("NUMBER SYSTEM"); // NEW
        
        

        
        


        
        // === Add buttons to the menu panel ===
        menuPanel.add(areaBtn);
        menuPanel.add(angleBtn);
        menuPanel.add(lengthBtn);
        menuPanel.add(weightBtn);
        menuPanel.add(currencyBtn);
        menuPanel.add(tempBtn);
        menuPanel.add(speedBtn);
        menuPanel.add(pressureBtn);
        menuPanel.add(numberBtn);
        

        converterContainer = new JPanel(new BorderLayout());

        // === Hook up each button to its corresponding panel ===
        areaBtn.addActionListener(e -> showPanel(new AreaPanel()));
        angleBtn.addActionListener(e -> showPanel(new AnglePanel()));
        lengthBtn.addActionListener(e -> showPanel(new LengthPanel()));
        weightBtn.addActionListener(e -> showPanel(new WeightPanel()));
        currencyBtn.addActionListener(e -> showPanel(new CurrencyPanel()));
        tempBtn.addActionListener(e -> showPanel(new TempraturePanel()));
        speedBtn.addActionListener(e -> showPanel(new SpeedPanel()));
        pressureBtn.addActionListener(e -> showPanel(new PressurePanel()));
        numberBtn.addActionListener(e -> showPanel(new NumberSystemPanel()));
        

        mainCardPanel.add(menuPanel, "MENU");
        mainCardPanel.add(converterContainer, "CONVERTER");
        add(mainCardPanel);
    }

    private void showPanel(JPanel panel) {
        converterContainer.removeAll();
        converterContainer.add(panel, BorderLayout.CENTER);

        JButton backBtn = new JButton("BACK TO MENU");
        backBtn.setPreferredSize(new Dimension(200, 40));
        backBtn.setFont(new Font("Arial", Font.PLAIN, 14));
        backBtn.setFocusPainted(false);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setPreferredSize(new Dimension(520, 60));
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 10));
        buttonPanel.add(backBtn);

        backBtn.addActionListener(event -> {
            converterContainer.removeAll();
            cardLayout.show(mainCardPanel, "MENU");
        });

        converterContainer.add(buttonPanel, BorderLayout.SOUTH);
        converterContainer.revalidate();
        converterContainer.repaint();
        cardLayout.show(mainCardPanel, "CONVERTER");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainFrame().setVisible(true));
    }
}